package dominio;

import org.example.dominio.Carrera;
import org.example.dominio.Facultad;

public class TestFacultad {
    public static void main(String[] args) {
        // Crear instancia de Facultad
        Facultad facultad = new Facultad();
        facultad.setIdFacultad("F001");
        facultad.setNombre("Facultad de Ingeniería");
        facultad.setUbicacion("Campus Central");
        facultad.setDecano("Dra. Laura Pérez");

        // Crear algunas carreras
        Carrera c1 = new Carrera("C001", "Ingeniería de Sistemas", 5, "Ingeniero de Sistemas");
        Carrera c2 = new Carrera("C002", "Ingeniería Civil", 5, "Ingeniero Civil");

        // Agregar carreras a la facultad
        facultad.agregarCarrera(c1);
        facultad.agregarCarrera(c2);

        // Listar carreras de la facultad
        facultad.listarCarreras();

        // Mostrar datos de la facultad
        System.out.println(facultad);
    }
}

