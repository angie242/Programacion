package dominio;

import org.example.dominio.Carrera;

public class TestCarrera {
    public static void main(String[] args) {

        // Crear instancia con constructor vacío
        Carrera carrera1 = new Carrera();
        carrera1.setIdCarrera("C001");
        carrera1.setCarrera("Ingeniería de Sistemas");
        carrera1.setDuracion(5);
        carrera1.setTitulo("Ingeniero de Sistemas");

        // Probar métodos
        carrera1.asignarEstudiante("Juan Pérez");
        carrera1.obtenerPracticas();

        System.out.println(carrera1);

        // Crear instancia con constructor parametrizado
        Carrera carrera2 = new Carrera("C002", "Administración", 4, "Licenciado en Administración");
        carrera2.asignarEstudiante("María López");
        carrera2.obtenerPracticas();

        System.out.println(carrera2);
    }
}