package dominio;

import org.example.dominio.Usuario;

public class TestUsuario {
    public static void main(String[] args) {
        // Crear instancia con constructor vacío
        Usuario usuario1 = new Usuario();
        usuario1.setIdUsuario("U001");
        usuario1.setNombre("Carlos");
        usuario1.setApellido("González");
        usuario1.setCorreo("carlos@mail.com");
        usuario1.setContrasena("clave123");

        usuario1.iniciarSesion();
        usuario1.cerrarSesion();

        System.out.println(usuario1);

        // Crear instancia con constructor parametrizado
        Usuario usuario2 = new Usuario("U002", "María", "Lopez", "maria@mail.com", "pass456");
        usuario2.iniciarSesion();
        usuario2.cerrarSesion();

        System.out.println(usuario2);
    }
}
