package dominio;

import org.example.dominio.Practica;

import java.util.Date;

public class TestPractica {
    public static void main(String[] args) {

        // Crear una práctica usando el constructor vacío
        Practica practica1 = new Practica();
        practica1.setIdPractica("P001");
        practica1.setEmpresa("TechCorp");
        practica1.setPuesto("Desarrollador Backend");
        practica1.setUbicacion("Lima");
        practica1.setFechaInicio(new Date());
        practica1.setFechaFin(new Date());
        practica1.setDescripcion("Desarrollo de aplicaciones en Java");
        practica1.setRequisitos("Conocimiento en Spring Boot");
        practica1.setDuracion(6);

        practica1.registrarPractica();
        practica1.listarPostulaciones();
        practica1.asignarDocenteSupervisor();

        System.out.println(practica1);

        // Crear una práctica usando el constructor completo
        Practica practica2 = new Practica(
                "P002",
                "SoftSolutions",
                "Tester QA",
                "Arequipa",
                new Date(),
                new Date(),
                "Pruebas automatizadas",
                "Saber usar Selenium",
                3
        );

        practica2.registrarPractica();
        practica2.listarPostulaciones();
        practica2.asignarDocenteSupervisor();

        System.out.println(practica2);
    }
}

