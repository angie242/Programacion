package dominio;

import org.example.dominio.Docente;

public class TestDocente {
    public static void main(String[] args) {

        // Usando constructor vacío
        Docente docente1 = new Docente();
        docente1.setIdDocente("D001");
        docente1.setEspecialidad("Física");
        docente1.setDepartamento("Ciencias Naturales");

        docente1.revisarProgresoEstudiante();
        docente1.aprobarPractica();
        docente1.emitirComentarios();
        docente1.enviarNotificacion();

        System.out.println(docente1);

        // Usando constructor con parámetros
        Docente docente2 = new Docente("D002", "Programación", "Ingeniería de Sistemas");
        docente2.revisarProgresoEstudiante();
        docente2.aprobarPractica();
        docente2.emitirComentarios();
        docente2.enviarNotificacion();

        System.out.println(docente2);
    }
}
