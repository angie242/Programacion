package dominio;

import org.example.dominio.Estudiante;

public class TestEstudiante {
    public static void main(String[] args) {
        // Crear instancia con constructor vacío
        Estudiante estudiante1 = new Estudiante();
        estudiante1.setIdEstudiante(101);
        estudiante1.setCodigoEstudiante("20231001");
        estudiante1.setSemestre(5);

        estudiante1.postularPractica();
        estudiante1.consultarProgreso();
        estudiante1.recibirNotificacion();

        System.out.println(estudiante1);

        // Crear instancia con constructor parametrizado
        Estudiante estudiante2 = new Estudiante(102, "20231002", 8);
        estudiante2.postularPractica();
        estudiante2.consultarProgreso();
        estudiante2.recibirNotificacion();

        System.out.println(estudiante2);
    }
}
