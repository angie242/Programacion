package dominio;

import org.example.dominio.Progreso;

import java.util.Date;

public class TestProgreso {
    public static void main(String[] args) {

        // Progreso con constructor vacío
        Progreso progreso1 = new Progreso();
        progreso1.actualizarProgreso("El estudiante completó el módulo 1");
        progreso1.verHistorial();
        System.out.println(progreso1);

        // Progreso con constructor parametrizado
        Progreso progreso2 = new Progreso("Inicio de la práctica", new Date());
        progreso2.verHistorial();
        System.out.println(progreso2);
    }
}
