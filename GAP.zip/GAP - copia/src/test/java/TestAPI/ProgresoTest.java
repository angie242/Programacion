package TestAPI;

import org.example.dominio.Progreso;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class ProgresoTest {

    private Progreso progreso;

    @BeforeEach
    void setUp() {
        progreso = new Progreso();
    }

    @Test
    void testSetAndGetComentarios() {
        progreso.setComentarios("Completó el 50% del trabajo");
        assertEquals("Completó el 50% del trabajo", progreso.getComentarios());
    }

    @Test
    void testSetAndGetFechaActualizacion() {
        Date fecha = new Date();
        progreso.setFechaActualizacion(fecha);
        assertEquals(fecha, progreso.getFechaActualizacion());
    }

    @Test
    void testActualizarProgreso() {
        progreso.actualizarProgreso("Nuevo comentario");
        assertEquals("Nuevo comentario", progreso.getComentarios());
        assertNotNull(progreso.getFechaActualizacion());
    }
}
