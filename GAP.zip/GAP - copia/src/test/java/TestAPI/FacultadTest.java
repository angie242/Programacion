package TestAPI;

import org.example.dominio.Facultad;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FacultadTest {

    private Facultad facultad;

    @BeforeEach
    void setUp() {
        facultad = new Facultad();
    }

    @Test
    void getIdFacultad() {
        facultad.setIdFacultad("FAC01");
        assertEquals("FAC01", facultad.getIdFacultad());
    }

    @Test
    void setIdFacultad() {
        facultad.setIdFacultad("FAC02");
        assertEquals("FAC02", facultad.getIdFacultad());
    }

    @Test
    void getNombre() {
        facultad.setNombre("Facultad de Ingeniería");
        assertEquals("Facultad de Ingeniería", facultad.getNombre());
    }

    @Test
    void setNombre() {
        facultad.setNombre("Facultad de Ciencias");
        assertEquals("Facultad de Ciencias", facultad.getNombre());
    }

    @Test
    void getUbicacion() {
        facultad.setUbicacion("Quito - Campus Central");
        assertEquals("Quito - Campus Central", facultad.getUbicacion());
    }

    @Test
    void setUbicacion() {
        facultad.setUbicacion("Cuenca - Campus Sur");
        assertEquals("Cuenca - Campus Sur", facultad.getUbicacion());
    }
}