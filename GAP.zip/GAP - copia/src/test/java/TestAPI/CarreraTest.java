package TestAPI;

import org.example.dominio.Carrera;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CarreraTest {

    private Carrera carrera;

    @BeforeEach
    void setUp() {
        carrera = new Carrera(); // Constructor por defecto
    }

    @Test
    void getIdCarrera() {
        carrera.setIdCarrera("CR001");
        assertEquals("CR001", carrera.getIdCarrera());
    }

    @Test
    void setIdCarrera() {
        carrera.setIdCarrera("CR002");
        assertEquals("CR002", carrera.getIdCarrera());
    }

    @Test
    void getNombreCarrera() {
        carrera.setCarrera("Ingeniería de Sistemas");
        assertEquals("Ingeniería de Sistemas", carrera.getCarrera());
    }

    @Test
    void setNombreCarrera() {
        carrera.setCarrera("Administración");
        assertEquals("Administración", carrera.getCarrera());
    }

    @Test
    void getTitulo() {
        carrera.setTitulo("Ingeniero de Sistemas");
        assertEquals("Ingeniero de Sistemas", carrera.getTitulo());
    }

    @Test
    void setTitulo() {
        carrera.setTitulo("Licenciado en Administración");
        assertEquals("Licenciado en Administración", carrera.getTitulo());
    }
}

