package org.example.dominio;

public class Estudiante {
    private int idEstudiante;
    private String codigoEstudiante;
    private int semestre;

    public Estudiante() {
        this.idEstudiante = 0;
        this.codigoEstudiante = "";
        this.semestre = 1;
    }

    public Estudiante(int idEstudiante, String codigoEstudiante, int semestre) {
        this.idEstudiante = idEstudiante;
        this.codigoEstudiante = codigoEstudiante;
        this.semestre = semestre;
    }

    public int getIdEstudiante() {
        return idEstudiante;
    }

    public void setIdEstudiante(int nIdEstudiante) {
        if (nIdEstudiante > 0) {
            this.idEstudiante = nIdEstudiante;
        } else {
            System.out.println("Error: ID inválido");
            this.idEstudiante = 0;
        }
    }

    public String getCodigoEstudiante() {
        return codigoEstudiante;
    }

    public void setCodigoEstudiante(String nCodigoEstudiante) {
        if (nCodigoEstudiante != null && !nCodigoEstudiante.trim().isEmpty()) {
            this.codigoEstudiante = nCodigoEstudiante;
        } else {
            System.out.println("Error: Código de estudiante inválido");
            this.codigoEstudiante = "null";
        }
    }

    public int getSemestre() {
        return semestre;
    }

    public void setSemestre(int nSemestre) {
        if (nSemestre >= 1 && nSemestre <= 12) {
            this.semestre = nSemestre;
        } else {
            System.out.println("Error: Semestre inválido (debe ser entre 1 y 12)");
            this.semestre = 1;
        }
    }

    public void postularPractica() {
        System.out.println("El estudiante " + codigoEstudiante + " ha postulado a una práctica.");
    }

    public void consultarProgreso() {
        System.out.println("Consultando progreso académico del estudiante " + codigoEstudiante);
    }

    public void recibirNotificacion() {
        System.out.println("El estudiante " + codigoEstudiante + " ha recibido una notificación.");
    }

    @Override
    public String toString() {
        return "Estudiante [ID=" + idEstudiante + ", Código=" + codigoEstudiante + ", Semestre=" + semestre + "]";
    }
}


