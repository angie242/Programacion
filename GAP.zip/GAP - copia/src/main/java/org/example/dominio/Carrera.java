package org.example.dominio;

public class Carrera {
    private String idCarrera;
    private String carrera;
    private int duracion;
    private String titulo;

    public Carrera() {
        this.idCarrera = "";
        this.carrera = "";
        this.duracion = 1;
        this.titulo = "";
    }

    public Carrera(String idCarrera, String carrera, int duracion, String titulo) {
        this.idCarrera = idCarrera;
        this.carrera = carrera;
        this.duracion = duracion;
        this.titulo = titulo;
    }

    public String getIdCarrera() {
        return idCarrera;
    }

    public void setIdCarrera(String nIdCarrera) {
        if (nIdCarrera != null && !nIdCarrera.trim().isEmpty()) {
            this.idCarrera = nIdCarrera;
        } else {
            System.out.println("Error: ID inválido");
            this.idCarrera = "null";
        }
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String nCarrera) {
        if (nCarrera != null && !nCarrera.trim().isEmpty()) {
            this.carrera = nCarrera;
        } else {
            System.out.println("Error: Nombre de carrera inválido");
            this.carrera = "null";
        }
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int nduracion) {
        if (nduracion >= 0) {
            this.duracion = nduracion;
        } else {
            System.out.println("Error: Duración inválida");
        }
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String nTitulo) {
        if (nTitulo != null && !nTitulo.trim().isEmpty()) {
            this.titulo = nTitulo;
        } else {
            System.out.println("Error: Título inválido");
            this.titulo = "null";
        }
    }

    public void asignarEstudiante(String nombreEstudiante) {
        if (nombreEstudiante != null && !nombreEstudiante.trim().isEmpty()) {
            System.out.println("Estudiante " + nombreEstudiante + " asignado a la carrera " + carrera);
        } else {
            System.out.println("Error: Nombre de estudiante inválido");
        }
    }

    public void obtenerPracticas() {
        System.out.println("Obteniendo prácticas disponibles para la carrera " + carrera);
        // Aquí podría ir lógica para obtener prácticas específicas.
    }

    @Override
    public String toString() {
        return "Carrera [ID=" + idCarrera + ", Nombre=" + carrera + ", Duración=" + duracion + ", Título=" + titulo + "]";
    }
}


