package org.example.dominio;

import java.util.Date;

public class Progreso {

    private String comentarios;
    private Date fechaActualizacion;

    public Progreso() {
        this.comentarios = "";
        this.fechaActualizacion = new Date();
    }

    public Progreso(String comentarios, Date fechaActualizacion) {
        setComentarios(comentarios);
        setFechaActualizacion(fechaActualizacion);
    }

    public String getComentarios() {
        return comentarios;
    }

    public void setComentarios(String comentarios) {
        if (comentarios != null && !comentarios.trim().isEmpty()) {
            this.comentarios = comentarios;
        } else {
            System.out.println("Error: Comentarios inválidos");
            this.comentarios = "null";
        }
    }

    public Date getFechaActualizacion() {
        return fechaActualizacion;
    }

    public void setFechaActualizacion(Date fechaActualizacion) {
        if (fechaActualizacion != null) {
            this.fechaActualizacion = fechaActualizacion;
        } else {
            System.out.println("Error: Fecha inválida");
            this.fechaActualizacion = new Date();
        }
    }

    public void actualizarProgreso(String nuevosComentarios) {
        setComentarios(nuevosComentarios);
        setFechaActualizacion(new Date());
        System.out.println("Progreso actualizado con nuevos comentarios.");
    }

    public void verHistorial() {
        System.out.println("Historial de progreso:");
        System.out.println("Comentarios: " + comentarios);
        System.out.println("Fecha de Actualización: " + fechaActualizacion);
    }

    @Override
    public String toString() {
        return "Progreso [Comentarios=" + comentarios + ", FechaActualización=" + fechaActualizacion + "]";
    }
}

