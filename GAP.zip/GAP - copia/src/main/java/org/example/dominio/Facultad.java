package org.example.dominio;

import java.util.ArrayList;
import java.util.List;

public class Facultad {
    private String idFacultad;
    private String nombre;
    private String ubicacion;
    private String decano;

    private List<Carrera> carreras;

    public Facultad() {
        this.idFacultad = "";
        this.nombre = "";
        this.ubicacion = "";
        this.decano = "";
        this.carreras = new ArrayList<>();
    }

    public Facultad(String id, String nombre, String ubicacion, String decano) {
    }

    public String getIdFacultad() {
        return idFacultad;
    }

    public void setIdFacultad(String idFacultad) {
        if (idFacultad != null && !idFacultad.trim().isEmpty()) {
            this.idFacultad = idFacultad;
        } else {
            System.out.println("Error: ID de facultad inválido");
            this.idFacultad = "null";
        }
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if (nombre != null && !nombre.trim().isEmpty()) {
            this.nombre = nombre;
        } else {
            System.out.println("Error: Nombre inválido");
            this.nombre = "null";
        }
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        if (ubicacion != null && !ubicacion.trim().isEmpty()) {
            this.ubicacion = ubicacion;
        } else {
            System.out.println("Error: Ubicación inválida");
            this.ubicacion = "null";
        }
    }

    public String getDecano() {
        return decano;
    }

    public void setDecano(String decano) {
        if (decano != null && !decano.trim().isEmpty()) {
            this.decano = decano;
        } else {
            System.out.println("Error: Decano inválido");
            this.decano = "null";
        }
    }

    public void agregarCarrera(Carrera carrera) {
        if (carrera != null) {
            carreras.add(carrera);
            System.out.println("Carrera " + carrera.getCarrera() + " agregada a la facultad " + nombre);
        } else {
            System.out.println("Error: Carrera nula no puede ser agregada");
        }
    }

    public void listarCarreras() {
        if (carreras.isEmpty()) {
            System.out.println("No hay carreras en la facultad " + nombre);
        } else {
            System.out.println("Carreras en la facultad " + nombre + ":");
            for (Carrera c : carreras) {
                System.out.println("- " + c.getCarrera());
            }
        }
    }

    @Override
    public String toString() {
        return "Facultad [ID=" + idFacultad + ", Nombre=" + nombre + ", Ubicación=" + ubicacion + ", Decano=" + decano + "]";
    }
}

