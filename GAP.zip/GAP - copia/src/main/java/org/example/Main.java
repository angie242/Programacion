package org.example;
import org.example.consola.menu;

public class Main {
    public static void main(String[] args) {
        menu.main(args);
    }
}

