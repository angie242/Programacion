package org.example;

import org.example.Cruds.*;
import org.example.util.Repositorios;

import java.util.Scanner;

public class MenuPrincipalCruds {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Instanciar repositorios
        Repositorios.CarreraRepo carreraRepo = new Repositorios.CarreraRepo();
        Repositorios.DocenteRepo docenteRepo = new Repositorios.DocenteRepo();
        Repositorios.EstudianteRepo estudianteRepo = new Repositorios.EstudianteRepo();
        Repositorios.NotificacionRepo notificacionRepo = new Repositorios.NotificacionRepo();
        Repositorios.UsuarioRepo usuarioRepo = new Repositorios.UsuarioRepo();
        Repositorios.FacultadRepo facultadRepo = new Repositorios.FacultadRepo();
        Repositorios.PostulacionRepo postulacionRepo = new Repositorios.PostulacionRepo();
        Repositorios.PracticaRepo practicaRepo = new Repositorios.PracticaRepo();
        Repositorios.ProgresoRepo progresoRepo = new Repositorios.ProgresoRepo();

        while (true) {
            System.out.println("\n=== MENÚ PRINCIPAL ===");
            System.out.println("1. CRUD Carrera");
            System.out.println("2. CRUD Docente");
            System.out.println("3. CRUD Estudiante");
            System.out.println("4. CRUD Notificación");
            System.out.println("5. CRUD Usuario");
            System.out.println("6. CRUD Facultad");
            System.out.println("7. CRUD Postulación");
            System.out.println("8. CRUD Práctica");
            System.out.println("9. CRUD Progreso");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");

            String opcion = scanner.nextLine();

            switch (opcion) {
                case "1":
                    CrudCarrera.ejecutar(scanner, carreraRepo);
                    break;
                case "2":
                    CrudDocente.ejecutar(scanner, docenteRepo);
                    break;
                case "3":
                    CrudEstudiante.ejecutar(scanner, estudianteRepo);
                    break;
                case "4":
                    CrudNotificacion.ejecutar(scanner, notificacionRepo);
                    break;
                case "5":
                    CrudUsuario.ejecutar(scanner, usuarioRepo);
                    break;
                case "6":
                    CrudFacultad.ejecutar(scanner, facultadRepo);
                    break;
                case "7":
                    CrudPostulacion.ejecutar(scanner, postulacionRepo);
                    break;
                case "8":
                    CrudPractica.ejecutar(scanner, practicaRepo);
                    break;
                case "9":
                    CrudProgreso.ejecutar(scanner, progresoRepo);
                    break;
                case "0":
                    System.out.println("¡Hasta pronto!");
                    return;
                default:
                    System.out.println("Opción inválida. Intente de nuevo.");
            }
        }
    }
}

