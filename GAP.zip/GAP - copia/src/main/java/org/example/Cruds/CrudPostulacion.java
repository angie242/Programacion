package org.example.Cruds;

import org.example.dominio.Postulacion;
import org.example.dominio.Estudiante;
import org.example.dominio.Practica;
import org.example.util.Repositorios;

import java.util.Date;
import java.util.Scanner;
import java.text.SimpleDateFormat;

public class CrudPostulacion {
    public static void ejecutar(
            Scanner scanner,
            Repositorios.PostulacionRepo postulacionRepo,
            Repositorios.EstudianteRepo estudianteRepo,
            Repositorios.PracticaRepo practicaRepo
    ) {
        while (true) {
            System.out.println("\n--- CRUD Postulación ---");
            System.out.println("1. Agregar postulación");
            System.out.println("2. Listar postulaciones");
            System.out.println("3. Buscar postulación por ID");
            System.out.println("4. Actualizar postulación");
            System.out.println("5. Eliminar postulación");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");

            String opcion = scanner.nextLine();

            switch (opcion) {
                case "1":
                    System.out.print("ID de postulación: ");
                    String id = scanner.nextLine();

                    System.out.print("ID de estudiante: ");
                    int idEst = leerEntero(scanner);
                    Estudiante estudiante = estudianteRepo.buscarPorId(idEst);
                    if (estudiante == null) {
                        System.out.println("Estudiante no encontrado.");
                        break;
                    }

                    System.out.print("ID de práctica: ");
                    String idPractica = scanner.nextLine();
                    Practica practica = practicaRepo.buscarPorId(idPractica);
                    if (practica == null) {
                        System.out.println("Práctica no encontrada.");
                        break;
                    }

                    System.out.print("Fecha de postulación (YYYY-MM-DD): ");
                    Date fecha = leerFecha(scanner);

                    System.out.print("Estado: ");
                    String estado = scanner.nextLine();

                    System.out.print("Documentos: ");
                    String documentos = scanner.nextLine();

                    Postulacion nueva = new Postulacion(id, estudiante, practica, fecha, estado, documentos);
                    postulacionRepo.agregar(nueva);
                    System.out.println("Postulación agregada.");
                    break;

                case "2":
                    System.out.println("Lista de postulaciones:");
                    postulacionRepo.listar().forEach(System.out::println);
                    break;

                case "3":
                    System.out.print("ID de postulación a buscar: ");
                    String idBuscar = scanner.nextLine();
                    Postulacion encontrada = postulacionRepo.buscarPorId(idBuscar);
                    System.out.println(encontrada != null ? encontrada : "No se encontró.");
                    break;

                case "4":
                    System.out.print("ID de postulación a actualizar: ");
                    String idAct = scanner.nextLine();
                    Postulacion p = postulacionRepo.buscarPorId(idAct);
                    if (p != null) {
                        System.out.print("Nuevo ID de estudiante: ");
                        int nuevoIdEst = leerEntero(scanner);
                        Estudiante nuevoEstudiante = estudianteRepo.buscarPorId(nuevoIdEst);
                        if (nuevoEstudiante == null) {
                            System.out.println("Estudiante no encontrado.");
                            break;
                        }

                        System.out.print("Nuevo ID de práctica: ");
                        String nuevoIdPractica = scanner.nextLine();
                        Practica nuevaPractica = practicaRepo.buscarPorId(nuevoIdPractica);
                        if (nuevaPractica == null) {
                            System.out.println("Práctica no encontrada.");
                            break;
                        }

                        System.out.print("Nueva fecha de postulación (YYYY-MM-DD): ");
                        Date nuevaFecha = leerFecha(scanner);

                        System.out.print("Nuevo estado: ");
                        String nuevoEstado = scanner.nextLine();

                        System.out.print("Nuevos documentos: ");
                        String nuevosDocs = scanner.nextLine();

                        Postulacion actualizada = new Postulacion(idAct, nuevoEstudiante, nuevaPractica, nuevaFecha, nuevoEstado, nuevosDocs);
                        postulacionRepo.actualizar(actualizada);
                        System.out.println("Postulación actualizada.");
                    } else {
                        System.out.println("Postulación no encontrada.");
                    }
                    break;

                case "5":
                    System.out.print("ID de postulación a eliminar: ");
                    String idEliminar = scanner.nextLine();
                    if (postulacionRepo.eliminar(idEliminar))
                        System.out.println("Eliminada correctamente.");
                    else
                        System.out.println("No se encontró.");
                    break;

                case "0":
                    return;

                default:
                    System.out.println("Opción inválida.");
            }
        }
    }

    private static int leerEntero(Scanner scanner) {
        try {
            return Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Entrada inválida. Intente con un número.");
            return leerEntero(scanner);
        }
    }

    private static Date leerFecha(Scanner scanner) {
        try {
            String fecha = scanner.nextLine();
            return new SimpleDateFormat("yyyy-MM-dd").parse(fecha);
        } catch (Exception e) {
            System.out.println("Formato de fecha inválido. Intente nuevamente.");
            return leerFecha(scanner);
        }
    }

    public static void ejecutar(Scanner scanner, Repositorios.PostulacionRepo postulacionRepo) {
    }
}

