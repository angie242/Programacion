package org.example.Cruds;

import org.example.dominio.Carrera;
import org.example.util.Repositorios;

import java.util.Scanner;

public class CrudCarrera {
    public static void ejecutar(Scanner scanner, Repositorios.CarreraRepo carreraRepo) {
        while (true) {
            System.out.println("\n--- CRUD Carrera ---");
            System.out.println("1. Agregar carrera");
            System.out.println("2. Listar carreras");
            System.out.println("3. Buscar carrera por ID");
            System.out.println("4. Actualizar carrera");
            System.out.println("5. Eliminar carrera");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");

            String opcion = scanner.nextLine();
            switch (opcion) {
                case "1":
                    System.out.print("ID: ");
                    String id = scanner.nextLine();
                    System.out.print("Nombre: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Duración (años): ");
                    int duracion = leerEntero(scanner);
                    System.out.print("Título: ");
                    String titulo = scanner.nextLine();
                    Carrera nueva = new Carrera(id, nombre, duracion, titulo);
                    carreraRepo.agregar(nueva);
                    System.out.println("Carrera agregada.");
                    break;

                case "2":
                    System.out.println("Lista de carreras:");
                    carreraRepo.listar().forEach(System.out::println);
                    break;

                case "3":
                    System.out.print("Ingrese ID de carrera: ");
                    String idBuscar = scanner.nextLine();
                    Carrera encontrada = carreraRepo.buscarPorId(idBuscar);
                    if (encontrada != null) System.out.println(encontrada);
                    else System.out.println("No se encontró.");
                    break;

                case "4":
                    System.out.print("ID de carrera a actualizar: ");
                    String idAct = scanner.nextLine();
                    Carrera c = carreraRepo.buscarPorId(idAct);
                    if (c != null) {
                        System.out.print("Nuevo nombre: ");
                        String nuevoNombre = scanner.nextLine();
                        System.out.print("Nueva duración: ");
                        int nuevaDuracion = leerEntero(scanner);
                        System.out.print("Nuevo título: ");
                        String nuevoTitulo = scanner.nextLine();
                        Carrera actualizado = new Carrera(idAct, nuevoNombre, nuevaDuracion, nuevoTitulo);
                        carreraRepo.actualizar(actualizado);
                        System.out.println("Carrera actualizada.");
                    } else {
                        System.out.println("Carrera no encontrada.");
                    }
                    break;

                case "5":
                    System.out.print("ID de carrera a eliminar: ");
                    String idEliminar = scanner.nextLine();
                    if (carreraRepo.eliminar(idEliminar)) System.out.println("Eliminada correctamente.");
                    else System.out.println("No se encontró.");
                    break;

                case "0": return;
                default: System.out.println("Opción inválida.");
            }
        }
    }

    private static int leerEntero(Scanner scanner) {
        try {
            return Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Entrada inválida. Intente con un número.");
            return leerEntero(scanner);
        }
    }
}
