package org.example.Cruds;

import org.example.dominio.Usuario;
import org.example.util.Repositorios;

import java.util.Scanner;

public class CrudUsuario {

    public static void ejecutar(Scanner scanner, Repositorios.UsuarioRepo usuarioRepo) {
        while (true) {
            System.out.println("\n--- CRUD Usuario ---");
            System.out.println("1. Agregar usuario");
            System.out.println("2. Listar usuarios");
            System.out.println("3. Buscar usuario por ID");
            System.out.println("4. Actualizar usuario");
            System.out.println("5. Eliminar usuario");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");

            String opcion = scanner.nextLine();

            switch (opcion) {
                case "1":
                    System.out.print("ID: ");
                    String id = scanner.nextLine();
                    System.out.print("Nombre: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Apellido: ");
                    String apellido = scanner.nextLine();
                    System.out.print("Correo: ");
                    String correo = scanner.nextLine();
                    System.out.print("Contraseña: ");
                    String contrasena = scanner.nextLine();

                    Usuario nuevo = new Usuario(id, nombre, apellido, correo, contrasena);
                    usuarioRepo.agregar(nuevo);
                    System.out.println("Usuario agregado.");
                    break;

                case "2":
                    System.out.println("Lista de usuarios:");
                    usuarioRepo.listar().forEach(System.out::println);
                    break;

                case "3":
                    System.out.print("Ingrese ID de usuario: ");
                    String idBuscar = scanner.nextLine();
                    Usuario encontrado = usuarioRepo.buscarPorId(idBuscar);
                    System.out.println(encontrado != null ? encontrado : "No se encontró.");
                    break;

                case "4":
                    System.out.print("ID del usuario a actualizar: ");
                    String idAct = scanner.nextLine();
                    Usuario usuario = usuarioRepo.buscarPorId(idAct);
                    if (usuario != null) {
                        System.out.print("Nuevo nombre: ");
                        String nuevoNombre = scanner.nextLine();
                        System.out.print("Nuevo apellido: ");
                        String nuevoApellido = scanner.nextLine();
                        System.out.print("Nuevo correo: ");
                        String nuevoCorreo = scanner.nextLine();
                        System.out.print("Nueva contraseña: ");
                        String nuevaContrasena = scanner.nextLine();

                        Usuario actualizado = new Usuario(idAct, nuevoNombre, nuevoApellido, nuevoCorreo, nuevaContrasena);
                        usuarioRepo.actualizar(actualizado);
                        System.out.println("Usuario actualizado.");
                    } else {
                        System.out.println("Usuario no encontrado.");
                    }
                    break;

                case "5":
                    System.out.print("ID del usuario a eliminar: ");
                    String idEliminar = scanner.nextLine();
                    if (usuarioRepo.eliminar(idEliminar))
                        System.out.println("Usuario eliminado correctamente.");
                    else
                        System.out.println("No se encontró el usuario.");
                    break;

                case "0":
                    return;

                default:
                    System.out.println("Opción inválida.");
            }
        }
    }
}
