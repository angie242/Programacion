package org.example.Cruds;

import org.example.dominio.Practica;
import org.example.util.Repositorios;

import java.util.Date;
import java.util.Scanner;
import java.text.SimpleDateFormat;

public class CrudPractica {

    public static void ejecutar(Scanner scanner, Repositorios.PracticaRepo practicaRepo) {
        while (true) {
            System.out.println("\n--- CRUD Práctica ---");
            System.out.println("1. Agregar práctica");
            System.out.println("2. Listar prácticas");
            System.out.println("3. Buscar práctica por ID");
            System.out.println("4. Actualizar práctica");
            System.out.println("5. Eliminar práctica");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");

            String opcion = scanner.nextLine();

            switch (opcion) {
                case "1":
                    System.out.print("ID de práctica: ");
                    String id = scanner.nextLine();

                    System.out.print("Empresa: ");
                    String empresa = scanner.nextLine();

                    System.out.print("Puesto: ");
                    String puesto = scanner.nextLine();

                    System.out.print("Ubicación: ");
                    String ubicacion = scanner.nextLine();

                    System.out.print("Fecha de inicio (YYYY-MM-DD): ");
                    Date fechaInicio = leerFecha(scanner);

                    System.out.print("Fecha de fin (YYYY-MM-DD): ");
                    Date fechaFin = leerFecha(scanner);

                    System.out.print("Descripción: ");
                    String descripcion = scanner.nextLine();

                    System.out.print("Requisitos: ");
                    String requisitos = scanner.nextLine();

                    System.out.print("Duración (en meses): ");
                    int duracion = leerEntero(scanner);

                    Practica nueva = new Practica(id, empresa, puesto, ubicacion, fechaInicio, fechaFin, descripcion, requisitos, duracion);
                    practicaRepo.agregar(nueva);
                    System.out.println("Práctica agregada.");
                    break;

                case "2":
                    System.out.println("Lista de prácticas:");
                    practicaRepo.listar().forEach(System.out::println);
                    break;

                case "3":
                    System.out.print("ID de práctica a buscar: ");
                    String idBuscar = scanner.nextLine();
                    Practica encontrada = practicaRepo.buscarPorId(idBuscar);
                    System.out.println(encontrada != null ? encontrada : "No se encontró.");
                    break;

                case "4":
                    System.out.print("ID de práctica a actualizar: ");
                    String idAct = scanner.nextLine();
                    Practica actual = practicaRepo.buscarPorId(idAct);
                    if (actual != null) {
                        System.out.print("Empresa: ");
                        String nuevaEmpresa = scanner.nextLine();

                        System.out.print("Puesto: ");
                        String nuevoPuesto = scanner.nextLine();

                        System.out.print("Ubicación: ");
                        String nuevaUbicacion = scanner.nextLine();

                        System.out.print("Fecha de inicio (YYYY-MM-DD): ");
                        Date nuevaFechaInicio = leerFecha(scanner);

                        System.out.print("Fecha de fin (YYYY-MM-DD): ");
                        Date nuevaFechaFin = leerFecha(scanner);

                        System.out.print("Descripción: ");
                        String nuevaDescripcion = scanner.nextLine();

                        System.out.print("Requisitos: ");
                        String nuevosRequisitos = scanner.nextLine();

                        System.out.print("Duración (en meses): ");
                        int nuevaDuracion = leerEntero(scanner);

                        Practica nuevaPractica = new Practica(idAct, nuevaEmpresa, nuevoPuesto, nuevaUbicacion,
                                nuevaFechaInicio, nuevaFechaFin, nuevaDescripcion, nuevosRequisitos, nuevaDuracion);

                        practicaRepo.actualizar(nuevaPractica);
                        System.out.println("Práctica actualizada.");
                    } else {
                        System.out.println("Práctica no encontrada.");
                    }
                    break;

                case "5":
                    System.out.print("ID de práctica a eliminar: ");
                    String idEliminar = scanner.nextLine();
                    if (practicaRepo.eliminar(idEliminar))
                        System.out.println("Eliminada correctamente.");
                    else
                        System.out.println("No se encontró.");
                    break;

                case "0":
                    return;

                default:
                    System.out.println("Opción inválida.");
            }
        }
    }

    private static int leerEntero(Scanner scanner) {
        try {
            return Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Entrada inválida. Intente con un número.");
            return leerEntero(scanner);
        }
    }

    private static Date leerFecha(Scanner scanner) {
        try {
            String fecha = scanner.nextLine();
            return new SimpleDateFormat("yyyy-MM-dd").parse(fecha);
        } catch (Exception e) {
            System.out.println("Formato de fecha inválido. Intente nuevamente.");
            return leerFecha(scanner);
        }
    }
}

