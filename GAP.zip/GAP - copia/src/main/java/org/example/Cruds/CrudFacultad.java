package org.example.Cruds;


import org.example.dominio.Facultad;
import org.example.util.Repositorios;

import java.util.Scanner;

public class CrudFacultad {
    public static void ejecutar(Scanner scanner, Repositorios.FacultadRepo facultadRepo) {
        while (true) {
            System.out.println("\n--- CRUD Facultad ---");
            System.out.println("1. Agregar facultad");
            System.out.println("2. Listar facultades");
            System.out.println("3. Buscar facultad por ID");
            System.out.println("4. Actualizar facultad");
            System.out.println("5. Eliminar facultad");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");

            String opcion = scanner.nextLine();
            switch (opcion) {
                case "1":
                    System.out.print("ID: ");
                    String id = scanner.nextLine();
                    System.out.print("Nombre: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Ubicación: ");
                    String ubicacion = scanner.nextLine();
                    System.out.print("Decano: ");
                    String decano = scanner.nextLine();
                    Facultad nueva = new Facultad(id, nombre, ubicacion, decano);
                    facultadRepo.agregar(nueva);
                    System.out.println("Facultad agregada.");
                    break;

                case "2":
                    System.out.println("Lista de facultades:");
                    facultadRepo.listar().forEach(System.out::println);
                    break;

                case "3":
                    System.out.print("Ingrese ID de facultad: ");
                    String idBuscar = scanner.nextLine();
                    Facultad encontrada = facultadRepo.buscarPorId(idBuscar);
                    System.out.println(encontrada != null ? encontrada : "No se encontró.");
                    break;

                case "4":
                    System.out.print("ID de facultad a actualizar: ");
                    String idAct = scanner.nextLine();
                    Facultad actual = facultadRepo.buscarPorId(idAct);
                    if (actual != null) {
                        System.out.print("Nuevo nombre: ");
                        String nuevoNombre = scanner.nextLine();
                        System.out.print("Nueva ubicación: ");
                        String nuevaUbicacion = scanner.nextLine();
                        System.out.print("Nuevo decano: ");
                        String nuevoDecano = scanner.nextLine();
                        Facultad actualizado = new Facultad(idAct, nuevoNombre, nuevaUbicacion, nuevoDecano);
                        facultadRepo.actualizar(actualizado);
                        System.out.println("Facultad actualizada.");
                    } else {
                        System.out.println("Facultad no encontrada.");
                    }
                    break;

                case "5":
                    System.out.print("ID de facultad a eliminar: ");
                    String idEliminar = scanner.nextLine();
                    if (facultadRepo.eliminar(idEliminar))
                        System.out.println("Eliminada correctamente.");
                    else
                        System.out.println("No se encontró.");
                    break;

                case "0": return;
                default: System.out.println("Opción inválida.");
            }
        }
    }
}
