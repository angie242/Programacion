package org.example.Cruds;


import org.example.dominio.Estudiante;
import org.example.util.Repositorios;

import java.util.Scanner;

public class CrudEstudiante {
    public static void ejecutar(Scanner scanner, Repositorios.EstudianteRepo estudianteRepo) {
        while (true) {
            System.out.println("\n--- CRUD Estudiante ---");
            System.out.println("1. Agregar estudiante");
            System.out.println("2. Listar estudiantes");
            System.out.println("3. Buscar estudiante por ID");
            System.out.println("4. Actualizar estudiante");
            System.out.println("5. Eliminar estudiante");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");

            String opcion = scanner.nextLine();
            switch (opcion) {
                case "1":
                    System.out.print("ID (número): ");
                    int id = leerEntero(scanner);
                    System.out.print("Código: ");
                    String codigo = scanner.nextLine();
                    System.out.print("Semestre: ");
                    int semestre = leerEntero(scanner);
                    Estudiante nuevo = new Estudiante(id, codigo, semestre);
                    estudianteRepo.agregar(nuevo);
                    System.out.println("Estudiante agregado.");
                    break;

                case "2":
                    System.out.println("Lista de estudiantes:");
                    estudianteRepo.listar().forEach(System.out::println);
                    break;

                case "3":
                    System.out.print("ID de estudiante: ");
                    int idBuscar = leerEntero(scanner);
                    Estudiante encontrado = estudianteRepo.buscarPorId(idBuscar);
                    if (encontrado != null) System.out.println(encontrado);
                    else System.out.println("No se encontró.");
                    break;

                case "4":
                    System.out.print("ID de estudiante a actualizar: ");
                    int idAct = leerEntero(scanner);
                    Estudiante est = estudianteRepo.buscarPorId(idAct);
                    if (est != null) {
                        System.out.print("Nuevo código: ");
                        String nuevoCod = scanner.nextLine();
                        System.out.print("Nuevo semestre: ");
                        int nuevoSem = leerEntero(scanner);
                        Estudiante actualizado = new Estudiante(idAct, nuevoCod, nuevoSem);
                        estudianteRepo.actualizar(actualizado);
                        System.out.println("Estudiante actualizado.");
                    } else {
                        System.out.println("Estudiante no encontrado.");
                    }
                    break;

                case "5":
                    System.out.print("ID de estudiante a eliminar: ");
                    int idEliminar = leerEntero(scanner);
                    if (estudianteRepo.eliminar(idEliminar)) System.out.println("Eliminado correctamente.");
                    else System.out.println("No se encontró.");
                    break;

                case "0": return;
                default: System.out.println("Opción inválida.");
            }
        }
    }

    private static int leerEntero(Scanner scanner) {
        try {
            return Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Entrada inválida. Intente con un número.");
            return leerEntero(scanner);
        }
    }
}