package org.example.Cruds;

import org.example.dominio.Docente;
import org.example.util.Repositorios;

import java.util.Scanner;

public class CrudDocente {
    public static void ejecutar(Scanner scanner, Repositorios.DocenteRepo docenteRepo) {
        while (true) {
            System.out.println("\n--- CRUD Docente ---");
            System.out.println("1. Agregar docente");
            System.out.println("2. Listar docentes");
            System.out.println("3. Buscar docente por ID");
            System.out.println("4. Actualizar docente");
            System.out.println("5. Eliminar docente");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");

            String opcion = scanner.nextLine();
            switch (opcion) {
                case "1":
                    System.out.print("ID: ");
                    String id = scanner.nextLine();
                    System.out.print("Especialidad: ");
                    String especialidad = scanner.nextLine();
                    System.out.print("Departamento: ");
                    String departamento = scanner.nextLine();
                    Docente nuevo = new Docente(id, especialidad, departamento);
                    docenteRepo.agregar(nuevo);
                    System.out.println("Docente agregado.");
                    break;

                case "2":
                    System.out.println("Lista de docentes:");
                    docenteRepo.listar().forEach(System.out::println);
                    break;

                case "3":
                    System.out.print("Ingrese ID de docente: ");
                    String idBuscar = scanner.nextLine();
                    Docente encontrado = docenteRepo.buscarPorId(idBuscar);
                    if (encontrado != null) System.out.println(encontrado);
                    else System.out.println("No se encontró.");
                    break;

                case "4":
                    System.out.print("ID de docente a actualizar: ");
                    String idAct = scanner.nextLine();
                    Docente d = docenteRepo.buscarPorId(idAct);
                    if (d != null) {
                        System.out.print("Nueva especialidad: ");
                        String nuevaEsp = scanner.nextLine();
                        System.out.print("Nuevo departamento: ");
                        String nuevoDep = scanner.nextLine();
                        Docente actualizado = new Docente(idAct, nuevaEsp, nuevoDep);
                        docenteRepo.actualizar(actualizado);
                        System.out.println("Docente actualizado.");
                    } else {
                        System.out.println("Docente no encontrado.");
                    }
                    break;

                case "5":
                    System.out.print("ID de docente a eliminar: ");
                    String idEliminar = scanner.nextLine();
                    if (docenteRepo.eliminar(idEliminar)) System.out.println("Eliminado correctamente.");
                    else System.out.println("No se encontró.");
                    break;

                case "0": return;
                default: System.out.println("Opción inválida.");
            }
        }
    }
}