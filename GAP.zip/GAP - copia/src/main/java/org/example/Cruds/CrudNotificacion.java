package org.example.Cruds;

import org.example.dominio.Notificacion;
import org.example.util.Repositorios;

import java.util.Scanner;

public class CrudNotificacion {
    public static void ejecutar(Scanner scanner, Repositorios.NotificacionRepo notificacionRepo) {
        while (true) {
            System.out.println("\n--- CRUD Notificación ---");
            System.out.println("1. Agregar notificación");
            System.out.println("2. Listar notificaciones");
            System.out.println("3. Buscar notificación por ID");
            System.out.println("4. Eliminar notificación");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");

            String opcion = scanner.nextLine();
            switch (opcion) {
                case "1":
                    System.out.print("ID: ");
                    String id = scanner.nextLine();
                    System.out.print("Docente (nombre o ID): ");
                    String docente = scanner.nextLine();  // puedes adaptarlo a objetos reales
                    System.out.print("Fecha de envío (YYYY-MM-DD): ");
                    String fechaEnvio = scanner.nextLine();
                    System.out.print("Mensaje: ");
                    String mensaje = scanner.nextLine();

                    Notificacion nueva = new Notificacion(id, null, mensaje, fechaEnvio);  // Se pasa null en Docente
                    notificacionRepo.agregar(nueva);
                    System.out.println("Notificación agregada.");
                    break;

                case "2":
                    System.out.println("Lista de notificaciones:");
                    notificacionRepo.listar().forEach(System.out::println);
                    break;

                case "3":
                    System.out.print("Ingrese ID de notificación: ");
                    String idBuscar = scanner.nextLine();
                    Notificacion encontrada = notificacionRepo.buscarPorId(idBuscar);
                    System.out.println(encontrada != null ? encontrada : "No se encontró.");
                    break;

                case "4":
                    System.out.print("ID de notificación a eliminar: ");
                    String idEliminar = scanner.nextLine();
                    if (notificacionRepo.eliminar(idEliminar))
                        System.out.println("Eliminada correctamente.");
                    else
                        System.out.println("No se encontró.");
                    break;

                case "0": return;
                default: System.out.println("Opción inválida.");
            }
        }
    }
}
