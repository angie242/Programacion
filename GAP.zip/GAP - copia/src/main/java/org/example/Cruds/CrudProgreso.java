package org.example.Cruds;

import org.example.dominio.Progreso;
import org.example.util.Repositorios;

import java.util.Date;
import java.util.Scanner;
import java.text.SimpleDateFormat;

public class CrudProgreso {

    public static void ejecutar(Scanner scanner, Repositorios.ProgresoRepo progresoRepo) {
        while (true) {
            System.out.println("\n--- CRUD Progreso ---");
            System.out.println("1. Agregar progreso");
            System.out.println("2. Listar progresos");
            System.out.println("3. Buscar progreso por comentario");
            System.out.println("4. Actualizar progreso");
            System.out.println("5. Eliminar progreso");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");

            String opcion = scanner.nextLine();

            switch (opcion) {
                case "1":
                    System.out.print("Comentario: ");
                    String comentario = scanner.nextLine();

                    System.out.print("Fecha de actualización (YYYY-MM-DD): ");
                    Date fecha = leerFecha(scanner);

                    Progreso nuevo = new Progreso(comentario, fecha);
                    progresoRepo.agregar(nuevo);
                    System.out.println("Progreso agregado.");
                    break;

                case "2":
                    System.out.println("Lista de progresos:");
                    progresoRepo.listar().forEach(System.out::println);
                    break;

                case "3":
                    System.out.print("Comentario a buscar: ");
                    String buscar = scanner.nextLine();
                    Progreso encontrado = progresoRepo.buscarPorComentario(buscar);
                    System.out.println(encontrado != null ? encontrado : "No se encontró.");
                    break;

                case "4":
                    System.out.print("Comentario del progreso a actualizar: ");
                    String comentarioAntiguo = scanner.nextLine();
                    Progreso progreso = progresoRepo.buscarPorComentario(comentarioAntiguo);
                    if (progreso != null) {
                        System.out.print("Nuevo comentario: ");
                        String nuevoComentario = scanner.nextLine();

                        System.out.print("Nueva fecha de actualización (YYYY-MM-DD): ");
                        Date nuevaFecha = leerFecha(scanner);

                        Progreso actualizado = new Progreso(nuevoComentario, nuevaFecha);
                        progresoRepo.actualizar(actualizado);
                        System.out.println("Progreso actualizado.");
                    } else {
                        System.out.println("Progreso no encontrado.");
                    }
                    break;

                case "5":
                    System.out.print("Comentario del progreso a eliminar: ");
                    String eliminar = scanner.nextLine();
                    if (progresoRepo.eliminar(eliminar))
                        System.out.println("Eliminado correctamente.");
                    else
                        System.out.println("No se encontró.");
                    break;

                case "0":
                    return;

                default:
                    System.out.println("Opción inválida.");
            }
        }
    }

    private static Date leerFecha(Scanner scanner) {
        try {
            String fecha = scanner.nextLine();
            return new SimpleDateFormat("yyyy-MM-dd").parse(fecha);
        } catch (Exception e) {
            System.out.println("Formato de fecha inválido. Intente nuevamente.");
            return leerFecha(scanner);
        }
    }
}
