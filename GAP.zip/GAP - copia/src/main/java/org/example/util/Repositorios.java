package org.example.util;

import java.util.*;
import org.example.dominio.*;

public class Repositorios {

    // ===== CRUD Carrera =====
    public static class CarreraRepo {
        private List<Carrera> carreras = new ArrayList<>();

        public void agregar(Carrera c) { carreras.add(c); }
        public Carrera buscarPorId(String id) {
            return carreras.stream().filter(c -> c.getIdCarrera().equals(id)).findFirst().orElse(null);
        }
        public boolean actualizar(Carrera nueva) {
            Carrera actual = buscarPorId(nueva.getIdCarrera());
            if (actual != null) {
                actual.setCarrera(nueva.getCarrera());
                actual.setDuracion(nueva.getDuracion());
                actual.setTitulo(nueva.getTitulo());
                return true;
            }
            return false;
        }
        public boolean eliminar(String id) { return carreras.removeIf(c -> c.getIdCarrera().equals(id)); }
        public List<Carrera> listar() { return carreras; }
    }

    // ===== CRUD Docente =====
    public static class DocenteRepo {
        private List<Docente> docentes = new ArrayList<>();

        public void agregar(Docente d) { docentes.add(d); }
        public Docente buscarPorId(String id) {
            return docentes.stream().filter(d -> d.getIdDocente().equals(id)).findFirst().orElse(null);
        }
        public boolean actualizar(Docente nuevo) {
            Docente actual = buscarPorId(nuevo.getIdDocente());
            if (actual != null) {
                actual.setEspecialidad(nuevo.getEspecialidad());
                actual.setDepartamento(nuevo.getDepartamento());
                return true;
            }
            return false;
        }
        public boolean eliminar(String id) { return docentes.removeIf(d -> d.getIdDocente().equals(id)); }
        public List<Docente> listar() { return docentes; }
    }

    // ===== CRUD Estudiante =====
    public static class EstudianteRepo {
        private List<Estudiante> estudiantes = new ArrayList<>();

        public void agregar(Estudiante e) { estudiantes.add(e); }
        public Estudiante buscarPorId(int id) {
            return estudiantes.stream().filter(e -> e.getIdEstudiante() == id).findFirst().orElse(null);
        }
        public boolean actualizar(Estudiante nuevo) {
            Estudiante actual = buscarPorId(nuevo.getIdEstudiante());
            if (actual != null) {
                actual.setCodigoEstudiante(nuevo.getCodigoEstudiante());
                actual.setSemestre(nuevo.getSemestre());
                return true;
            }
            return false;
        }
        public boolean eliminar(int id) { return estudiantes.removeIf(e -> e.getIdEstudiante() == id); }
        public List<Estudiante> listar() { return estudiantes; }
    }

    // ===== CRUD Notificación =====
    public static class NotificacionRepo {
        private List<Notificacion> notificaciones = new ArrayList<>();

        public void agregar(Notificacion n) { notificaciones.add(n); }
        public Notificacion buscarPorId(String id) {
            return notificaciones.stream().filter(n -> n.getIdNotificacion().equals(id)).findFirst().orElse(null);
        }
        public boolean eliminar(String id) { return notificaciones.removeIf(n -> n.getIdNotificacion().equals(id)); }
        public List<Notificacion> listar() { return notificaciones; }
    }

    // ===== CRUD Usuario =====
    public static class UsuarioRepo {
        private List<Usuario> usuarios = new ArrayList<>();

        public void agregar(Usuario u) { usuarios.add(u); }
        public Usuario buscarPorId(String id) {
            return usuarios.stream().filter(u -> u.getIdUsuario().equals(id)).findFirst().orElse(null);
        }
        public boolean actualizar(Usuario nuevo) {
            Usuario actual = buscarPorId(nuevo.getIdUsuario());
            if (actual != null) {
                actual.setNombre(nuevo.getNombre());
                actual.setApellido(nuevo.getApellido());
                actual.setCorreo(nuevo.getCorreo());
                actual.setContrasena(nuevo.getContrasena());
                return true;
            }
            return false;
        }
        public boolean eliminar(String id) { return usuarios.removeIf(u -> u.getIdUsuario().equals(id)); }
        public List<Usuario> listar() { return usuarios; }
    }

    // ===== CRUD Facultad =====
    public static class FacultadRepo {
        private List<Facultad> facultades = new ArrayList<>();

        public void agregar(Facultad f) { facultades.add(f); }
        public Facultad buscarPorId(String id) {
            return facultades.stream().filter(f -> f.getIdFacultad().equals(id)).findFirst().orElse(null);
        }
        public boolean actualizar(Facultad nueva) {
            Facultad actual = buscarPorId(nueva.getIdFacultad());
            if (actual != null) {
                actual.setNombre(nueva.getNombre());
                actual.setUbicacion(nueva.getUbicacion());
                actual.setDecano(nueva.getDecano());
                return true;
            }
            return false;
        }
        public boolean eliminar(String id) { return facultades.removeIf(f -> f.getIdFacultad().equals(id)); }
        public List<Facultad> listar() { return facultades; }
    }

    // ===== CRUD Postulacion =====
    public static class PostulacionRepo {
        private List<Postulacion> postulaciones = new ArrayList<>();

        public void agregar(Postulacion p) { postulaciones.add(p); }
        public Postulacion buscarPorId(String id) {
            return postulaciones.stream().filter(p -> p.getIdPostulacion().equals(id)).findFirst().orElse(null);
        }
        public boolean actualizar(Postulacion nueva) {
            Postulacion actual = buscarPorId(nueva.getIdPostulacion());
            if (actual != null) {
                actual.setEstudiante(nueva.getEstudiante());
                actual.setPractica(nueva.getPractica());
                actual.setFechaPostulacion(nueva.getFechaPostulacion());
                actual.setEstado(nueva.getEstado());
                actual.setDocumentos(nueva.getDocumentos());
                return true;
            }
            return false;
        }
        public boolean eliminar(String id) { return postulaciones.removeIf(p -> p.getIdPostulacion().equals(id)); }
        public List<Postulacion> listar() { return postulaciones; }
    }

    // ===== CRUD Practica =====
    public static class PracticaRepo {
        private List<Practica> practicas = new ArrayList<>();

        public void agregar(Practica p) { practicas.add(p); }
        public Practica buscarPorId(String id) {
            return practicas.stream().filter(p -> p.getIdPractica().equals(id)).findFirst().orElse(null);
        }
        public boolean actualizar(Practica nueva) {
            Practica actual = buscarPorId(nueva.getIdPractica());
            if (actual != null) {
                actual.setEmpresa(nueva.getEmpresa());
                actual.setPuesto(nueva.getPuesto());
                actual.setUbicacion(nueva.getUbicacion());
                actual.setFechaInicio(nueva.getFechaInicio());
                actual.setFechaFin(nueva.getFechaFin());
                actual.setDescripcion(nueva.getDescripcion());
                actual.setRequisitos(nueva.getRequisitos());
                actual.setDuracion(nueva.getDuracion());
                return true;
            }
            return false;
        }
        public boolean eliminar(String id) { return practicas.removeIf(p -> p.getIdPractica().equals(id)); }
        public List<Practica> listar() { return practicas; }
    }

    // ===== CRUD Progreso =====
    public static class ProgresoRepo {
        private List<Progreso> progresos = new ArrayList<>();

        public void agregar(Progreso p) { progresos.add(p); }
        public Progreso buscarPorComentario(String comentario) {
            return progresos.stream().filter(p -> p.getComentarios().equals(comentario)).findFirst().orElse(null);
        }
        public boolean actualizar(Progreso nuevo) {
            Progreso actual = buscarPorComentario(nuevo.getComentarios());
            if (actual != null) {
                actual.setComentarios(nuevo.getComentarios());
                actual.setFechaActualizacion(nuevo.getFechaActualizacion());
                return true;
            }
            return false;
        }
        public boolean eliminar(String comentario) {
            return progresos.removeIf(p -> p.getComentarios().equals(comentario));
        }
        public List<Progreso> listar() { return progresos; }
    }
}

